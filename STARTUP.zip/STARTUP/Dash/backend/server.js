const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const mongoose = require('mongoose');

const app = express();
const PORT = 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Conectar ao MongoDB (substitua a URI pela sua)
mongoose.connect('mongodb://localhost:27017/wyn', { useNewUrlParser: true, useUnifiedTopology: true });

// Definir um modelo de Serviço
const serviceSchema = new mongoose.Schema({
    name: String,
    category: String,
    description: String,
    price: Number,
});

const Service = mongoose.model('Service', serviceSchema);

// Rotas
app.get('/services', async (req, res) => {
    const services = await Service.find();
    res.json(services);
});

app.post('/services', async (req, res) => {
    const service = new Service(req.body);
    await service.save();
    res.status(201).json(service);
});

// Iniciar o servidor
app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
