const express = require('express');
const { ImapFlow } = require('imapflow');
const { simpleParser } = require('mailparser');

const app = express();
const PORT = 3000;

app.get('/emails', async (req, res) => {
    const imap = new ImapFlow({
        host: 'imap.gmail.com',
        port: 993,
        secure: true,
        auth: {
            user: 'cris@gmail.com',
            pass: 'Cris123', // Se você tiver a autenticação de dois fatores, use um App Password
        }
    });

    try {
        await imap.connect();
        const lock = await imap.getMailboxLock('INBOX');
        const messages = [];

        for await (const message of imap.fetch('1:*', { envelope: true })) {
            messages.push({
                subject: message.envelope.subject,
                from: message.envelope.from[0].address,
            });
        }

        lock.release();
        res.json(messages);
    } catch (err) {
        console.error(err);
        res.status(500).send('Erro ao buscar e-mails.');
    } finally {
        await imap.logout();
    }
});

app.listen(PORT, () => {
    console.log(`Servidor rodando na porta ${PORT}`);
});
