// Gráfico de Solicitações de Serviços
var ctx = document.getElementById('servicesChart').getContext('2d');
var servicesChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['Jan', 'Feb', 'Mar'],
        datasets: [{
            label: 'Serviços Solicitados',
            data: [400, 500, 600],
            backgroundColor: 'orange',
            borderColor: 'orange',
            borderWidth: 1
        }]
    },
    options: {
        responsive: true,
        scales: {
            y: {
                beginAtZero: true
            }
        }
    }
});

// Gráfico de Satisfação
var ctx2 = document.getElementById('satisfactionChart').getContext('2d');
var satisfactionChart = new Chart(ctx2, {
    type: 'doughnut',
    data: {
        labels: ['28% satisfeitos', '50% neutros', '10% insatisfeitos'],
        datasets: [{
            data: [28, 50, 10],
            backgroundColor: ['#ffa500', '#cccccc', '#ff6347']
        }]
    },
    options: {
        responsive: true
    }
});

// Navegação entre as seções
function showDashboard() {
    hideAllSections();
    document.getElementById('dashboard-section').classList.remove('hidden');
    document.getElementById('update-graphs-section').classList.remove('hidden'); // Mostrar atualização dos gráficos
}

function showAddService() {
    hideAllSections();
    document.getElementById('add-service-section').classList.remove('hidden');
    document.getElementById('update-graphs-section').classList.add('hidden'); // Ocultar atualização dos gráficos
}

function showChat() {
    hideAllSections();
    document.getElementById('chat-section').classList.remove('hidden');
    document.getElementById('update-graphs-section').classList.add('hidden'); // Ocultar atualização dos gráficos
}

function showEditService() {
    hideAllSections();
    document.getElementById('edit-service-section').classList.remove('hidden');
    document.getElementById('update-graphs-section').classList.add('hidden'); // Ocultar atualização dos gráficos
}

function showConfig() {
    hideAllSections();
    document.getElementById('config-section').classList.remove('hidden');
    document.getElementById('update-graphs-section').classList.add('hidden'); // Ocultar atualização dos gráficos
}

function hideAllSections() {
    document.getElementById('dashboard-section').classList.add('hidden');
    document.getElementById('add-service-section').classList.add('hidden');
    document.getElementById('chat-section').classList.add('hidden');
    document.getElementById('edit-service-section').classList.add('hidden');
    document.getElementById('config-section').classList.add('hidden');
    document.getElementById('update-graphs-section').classList.add('hidden'); // Ocultar ao esconder todas as seções
}

// Função para adicionar serviço
async function addService() {
    var serviceName = document.getElementById('serviceName').value;
    var serviceCategory = document.getElementById('serviceCategory').value;
    var serviceDescription = document.getElementById('serviceDescription').value;
    var servicePrice = document.getElementById('servicePrice').value;

    // Validação básica
    if (!serviceName || !serviceCategory || !serviceDescription || !servicePrice) {
        alert("Por favor, preencha todos os campos.");
        return;
    }

    // Enviar dados para o backend
    const serviceData = {
        name: serviceName,
        category: serviceCategory,
        description: serviceDescription,
        price: servicePrice
    };

    try {
        const response = await fetch('http://localhost:5000/services', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(serviceData)
        });

        const newService = await response.json();
        // Atualizar a lista de serviços
        const servicesList = document.getElementById('servicesList');
        var newServiceDiv = document.createElement('div');
        newServiceDiv.textContent = `Nome: ${newService.name}, Categoria: ${newService.category}, Descrição: ${newService.description}, Preço: R$ ${newService.price}`;
        servicesList.appendChild(newServiceDiv);

        // Limpar campos
        document.getElementById('serviceName').value = '';
        document.getElementById('serviceCategory').value = '';
        document.getElementById('serviceDescription').value = '';
        document.getElementById('servicePrice').value = '';
    } catch (error) {
        console.error('Erro ao adicionar serviço:', error);
    }
}

// Função para enviar mensagem no chat
function sendMessage() {
    var messageInput = document.getElementById('messageInput').value;
    var chatBox = document.getElementById('chat-box');

    var messageEntry = document.createElement('div');
    messageEntry.textContent = messageInput;
    chatBox.appendChild(messageEntry);

    document.getElementById('messageInput').value = '';
}

// Função para salvar configurações
function saveSettings() {
    var username = document.getElementById('username').value;
    var email = document.getElementById('email').value;
    var password = document.getElementById('password').value;
    
    alert(`Configurações salvas!\nUsuário: ${username}\nEmail: ${email}`);
}

// Função para atualizar o gráfico de satisfação
function updateSatisfactionChart() {
    var promoters = parseInt(document.getElementById('promoters').value);
    var neutral = parseInt(document.getElementById('neutral').value);
    var detractors = parseInt(document.getElementById('detractors').value);

    satisfactionChart.data.datasets[0].data = [promoters, neutral, detractors];
    satisfactionChart.update();
}

// Função para atualizar o gráfico de serviços
function updateServicesChart() {
    var totalServices = parseInt(document.getElementById('totalServices').value);
    var completedServices = parseInt(document.getElementById('completedServices').value);
    
    // Atualiza os dados do gráfico de serviços
    servicesChart.data.datasets[0].data = [completedServices, totalServices - completedServices]; // Adiciona serviços concluídos e não concluídos
    servicesChart.update();
}
function getEmails() {
    fetch('http://localhost:3000/emails')
        .then(response => response.json())
        .then(data => {
            const emailsDiv = document.getElementById('emails');
            emailsDiv.innerHTML = ''; // Limpar e-mails antigos
            data.forEach(email => {
                emailsDiv.innerHTML += `<div><strong>De:</strong> ${email.from} <br><strong>Assunto:</strong> ${email.subject}</div><hr>`;
            });
        })
        .catch(err => console.error('Erro ao buscar e-mails:', err));
}
